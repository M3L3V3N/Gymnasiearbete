﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Pong
{
    public class Game1 : Game
    {
        Texture2D t;
        Vector2 cubePosition;
        double angle_x = 0,
        angle_y = 0,
        angle_z = 0;
        double depth = 500;
        private double delayTimer;
        private double delayDuration = 10;

        int[][] nodes = new int[][] 
        {
            new int[] {100, 100, -100},
            new int[] {100, -100, -100},
            new int[] {-100, -100, -100},
            new int[] {-100, 100, -100},
            new int[] {100, 100, 100},
            new int[] {100, -100, 100},
            new int[] {-100, -100, 100},
            new int[] {-100, 100, 100}
        };


        int[][] edges = new int[][]
        {
            new int[] {0, 1},
            new int[] {1, 2},
            new int[] {2, 3},
            new int[] {3, 0},
            new int[] {4, 5},
            new int[] {5, 6},
            new int[] {6, 7},
            new int[] {7, 4},
            new int[] {0, 4},
            new int[] {1, 5},
            new int[] {2, 6},
            new int[] {3, 7}
        };


        private GraphicsDeviceManager _graphics;
        private SpriteBatch spriteBatch;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            //IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            //cubePosition = new Vector2(_graphics.PreferredBackBufferWidth / 2,
            //_graphics.PreferredBackBufferHeight / 2);
            spriteBatch = new SpriteBatch(GraphicsDevice);
            t = new Texture2D(GraphicsDevice, 1, 1);
            t.SetData<Color>(
                new Color[] { Color.White });// fill the texture with white


            base.Initialize();
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            delayTimer += gameTime.ElapsedGameTime.TotalMilliseconds;

            // Check if the delay duration has passed
            if (delayTimer >= delayDuration)
            {
                angle_x += 0.01;
                angle_y += 0.01;
                angle_z += 0.01;

                GraphicsDevice.Clear(Color.Black);

                List<int[]> rotated_nodes = rotate(nodes, angle_x, angle_y, angle_z);


                spriteBatch.Begin();

                for (int i = 0; i < edges.GetLength(0); i++)
                {
                    int[] start = rotated_nodes[edges[i][0]];
                    int[] end = rotated_nodes[edges[i][1]];

                    int[] start_screen = convertCoord(start);
                    int[] end_screen = convertCoord(end);

                    //int[] start = nodes[edges[i][0]];
                    //int[] end = nodes[edges[i][1]];

                    //int[] start_screen = convertCoord(start);
                    //int[] end_screen = convertCoord(end);


                    DrawLine(spriteBatch, new Vector2(start_screen[0], start_screen[1]), new Vector2(end_screen[0], end_screen[1]));
                }

                spriteBatch.End();
                delayTimer = 0;
            }



            base.Draw(gameTime);
        }

        List<int[]> rotate(int[][] coordinates, double angle_x, double angle_y, double angle_z)
        {

            int new_x, new_y, new_z;
            List<int[]> new_nodes = new List<int[]>();

            //foreach (var coord in coordinates)
            for (int i = 0; i < coordinates.GetLength(0); i++)
            {
                int x = coordinates[i][0];
                int y = coordinates[i][1];
                int z = coordinates[i][2];

                //rotate around x-axis
                new_y = Convert.ToInt32(y * Math.Cos(angle_x) - z * Math.Sin(angle_x));
                new_z = Convert.ToInt32(y * Math.Sin(angle_x) + z * Math.Cos(angle_x));

                y = new_y;
                z = new_z;

                new_x = Convert.ToInt32(x * Math.Cos(angle_y) - z * Math.Sin(angle_y));
                new_z = Convert.ToInt32(x * Math.Sin(angle_y) + z * Math.Cos(angle_y));

                x = new_x;
                z = new_z;

                new_x = Convert.ToInt32(x * Math.Cos(angle_z) - y * Math.Sin(angle_z));
                new_y = Convert.ToInt32(x * Math.Sin(angle_z) + y * Math.Cos(angle_z));

                x = new_x;
                y = new_y;

                double depth_scale = depth / (depth - z);
                x = Convert.ToInt32(x * depth_scale);
                y = Convert.ToInt32(y * depth_scale);

                int[] ret_val = new int[] {x, y, z};
                new_nodes.Add(ret_val);

            }


           return (new_nodes);
        }


        int[] convertCoord(int[] coord)
        {
            int[] retcoord = new int[2];
            retcoord[0] = coord[0] + _graphics.PreferredBackBufferWidth / 2;
            retcoord[1] = coord[1] + _graphics.PreferredBackBufferHeight / 2;

            return (retcoord);
        }

        void DrawLine(SpriteBatch sb, Vector2 start, Vector2 end)
        {
            Vector2 edge = end - start;
            // calculate angle to rotate line
            float angle =
                (float)Math.Atan2(edge.Y, edge.X);


            sb.Draw(t,
                new Rectangle(// rectangle defines shape of line and position of start of line
                    (int)start.X,
                    (int)start.Y,
                    (int)edge.Length(), //sb will strech the texture to fill this rectangle
                    1), //width of line, change this to make thicker line
                null,
                Color.White, //colour of line
                angle,     //angle of line (calulated above)
                new Vector2(0, 0), // point in line about which to rotate
                SpriteEffects.None,
                0);

        }


    }
}