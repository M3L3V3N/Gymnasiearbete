﻿
using var game = new Pong.Game1();
game.Run();
